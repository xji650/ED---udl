import java.util.*;

public class MyArrayList<T> extends AbstractList<T> implements List<T> {

private static final int DEFAULT_CAPACITY = 10;
private static final int NOT_FOUND = -1;
private static final Object[] EMPTY_ELEMENTDATA = {};

private Object[] theArray;
private int theSize;
private int modCount;

public MyArrayList()
        {
        theSize = 0;
        theArray = new Object[DEFAULT_CAPACITY];
        }

public MyArrayList(Collection<? extends T> c) {
        this();
        if (!c.isEmpty())
        {
            theArray = c.toArray();
            theSize = c.size();
        }
        else
            theArray = EMPTY_ELEMENTDATA;
        }

public MyArrayList(int initialCapacity){
        if (initialCapacity > 0)
            theArray = new Object[initialCapacity];
        else if (initialCapacity == 0)
            theArray = EMPTY_ELEMENTDATA;
        else
            throw new IllegalArgumentException("Illegal Capacity: " +
        initialCapacity);
        }

@Override
public int size(){
        return theSize;
        }

public boolean isEmpty(){
        return theSize == 0;
        }

@Override
public boolean contains (Object o){
        return indexOf(o) >= 0;
        }

public int indexOf(Object o) {
        if (o == null)
        {
            for (int i = 0; i < theSize; i++){
                if (theArray[i] == null)
                    return i;
            }
        }
        else
        {
            for (int i = 0; i < theSize; i++){
                if (o.equals(theArray[i]))
                    return i;
            }
        }
        return -1;
        }

private void checkCapacity()   {
        if (theArray.length == theSize)  {
            int newCapacity = theArray.length*2 + 1;
            theArray = Arrays.copyOf(theArray, newCapacity);
        }
}

@Override
public boolean add(T e)
        {
        checkCapacity();
        modCount++;
        theArray[theSize++] = e;
        return true;
        }

@Override
public void add(int index, T e)
        {
        if  (index < 0 || index > theSize)
            throw new IndexOutOfBoundsException();
        checkCapacity();
        modCount++;
        System.arraycopy(theArray, index, theArray, index+1, theSize-index);
        theArray[index] = e;
        theSize++;
        }

@Override
public T remove (int index)
        {
        if  (index < 0 || index >= theSize)
            throw new IndexOutOfBoundsException();

        modCount++;
        T removedItem = (T)theArray[index];//downcast

        for (int i=index; i < theSize -1 ; i++)
        theArray[i] = theArray[i+1];

        theArray[--theSize] = null;

        return removedItem;

        }

@Override
public ListIterator<T> listIterator(int index)
        {
        if (index < 0 || index > theSize)
        throw new IndexOutOfBoundsException();
        return new ListItr(index);
        }

private class ListItr implements ListIterator<T>{

    int cursor; // index of the next element to return
    int lastReturned = -1; //index of the last element returned
    int expectedModCount = modCount; //amb aix√≤ comprobem si la llista
    //ha estat modificada despr√©s de la creaci√≥ de l'array per altres m√®todes
    //que no siguen l'add o el remove del mateix iterador

    ListItr (int index)
    {
        cursor = index;
    }

    @Override
    public boolean hasNext() {
        if (modCount != expectedModCount)
            throw new ConcurrentModificationException();
        return cursor < theSize;
    }

    @Override
    public T next() {
        if (!hasNext())
            throw new NoSuchElementException();
        lastReturned = cursor;
        cursor++;
        return (T) theArray[lastReturned];
    }

    @Override
    public boolean hasPrevious() {
        if (modCount != expectedModCount)
            throw new ConcurrentModificationException();
        return cursor != 0;
    }

    @Override
    public T previous() {
        if (!hasPrevious())
            throw new NoSuchElementException();
        lastReturned = cursor - 1;
        --cursor;
        return (T) theArray[lastReturned];
    }

    @Override
    public int nextIndex() {
        return cursor;
    }

    @Override
    public int previousIndex() {
        return cursor - 1;
    }

    //possiblement aquest m√®tode sigui exerici de Laboratori
    @Override
    public void remove() {
        if (lastReturned < 0) //amb aix√≤ comprovem que s'ha fet un next o previous
            throw new IllegalStateException();
        else if (modCount != expectedModCount)
            throw new ConcurrentModificationException();
        else
        {
            MyArrayList.this.remove(lastReturned);
            cursor = lastReturned;
            lastReturned = -1;
            expectedModCount = modCount;
        }
    }

    @Override
    public void set(T e) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void add(T e) {
        if (modCount != expectedModCount)
            throw new ConcurrentModificationException();
        MyArrayList.this.add(cursor, e); //cridem a l'add de la classe
        cursor++;
        lastReturned = -1;
        expectedModCount = modCount; //actualitzem el n√∫mero de modificacions
    }

}

    @Override
    public T get(int i) {

        if (i < 0 || i >= theSize)
            throw new IndexOutOfBoundsException();
        return (T) theArray[i];
    }

}
