import java.util.ListIterator;

public class TestMyArrayList {
    public static void main (String [] args){
        /*for (int i = 0; i < 10;)
            System.out.println(i++);
        for (int j = 0; j < 10;)
            System.out.println(++j);*/

        MyArrayList<Integer> array = new MyArrayList();
        System.out.println(array.size());
        System.out.println(array.isEmpty());
        array.add(1);
        array.add(4);
        System.out.println(array.contains(1));
        array.add(5);
        ListIterator<Integer> itr = array.listIterator();
        while (itr.hasNext()){
            System.out.println(itr.next());
            //itr.remove();
            //System.out.println("Element esborrat");
        }
        System.out.println("Està buit? " + array.isEmpty());
    }
}
